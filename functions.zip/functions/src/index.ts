import { onCall } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";
import * as logger from "firebase-functions/logger";

setGlobalOptions({ region: "us-central1" });

export const generateSayu = onCall({ secrets: ["GEMINI_API_KEY"] }, async (request) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY not set");
    }

    const prompt =
      request.data?.prompt ?? "오늘 하루를 짧은 일기로 작성해줘";

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      throw new Error("Gemini API Error: " + errText);
    }

    const data: any = await response.json();

    const text =
      data?.candidates?.[0]?.content?.parts?.[0]?.text ??
      "AI 응답 없음";

    return { text };
  } catch (e: any) {
    logger.error(e);
    throw new Error(e.message);
  }
});
