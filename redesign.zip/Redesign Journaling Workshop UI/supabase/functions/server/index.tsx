import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "X-User-Token"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-d095746c/health", (c) => {
  return c.json({ status: "ok" });
});

app.post("/make-server-d095746c/signup", async (c) => {
  const { email, password } = await c.req.json();
  
  if (!email || !password) {
    return c.json({ error: "Email and password are required" }, 400);
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') || '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '',
  );

  const { data, error } = await supabase.auth.admin.createUser({
    email: email,
    password: password,
    email_confirm: true
  });

  if (error) {
    console.error("Signup error:", error);
    return c.json({ error: error.message }, 400);
  }

  return c.json({ user: data.user });
});

// Records Sync Endpoint
app.get("/make-server-d095746c/records", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    const userToken = c.req.header("X-User-Token");
    
    // Authorization 헤더는 필수로 존재해야 함 (Gateway 통과용)
    if (!authHeader) {
      return c.json({ error: "Authorization header required" }, 401);
    }
    
    // 유저 인증 토큰 결정: X-User-Token 우선, 없으면 Authorization (Bearer 제거)
    const token = userToken || authHeader.split(" ")[1];
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') || '',
      Deno.env.get('SUPABASE_ANON_KEY') || '',
    );
    
    const { data: { user }, error } = await supabase.auth.getUser(token);
    
    if (error || !user) {
      console.error("Auth error:", error);
      return c.json({ error: "Invalid token" }, 401);
    }
    
    const key = `records_${user.id}`;
    let recordsJson;
    try {
      recordsJson = await kv.get(key);
    } catch (kvError) {
      console.error("KV get error:", kvError);
      recordsJson = null;
    }
    
    let records = [];
    try {
      if (recordsJson) {
        records = JSON.parse(recordsJson);
      }
    } catch (e) {
      console.error("Failed to parse records", e);
    }
    
    return c.json({ records });
  } catch (err) {
    console.error("Server internal error:", err);
    return c.json({ error: err.message }, 500);
  }
});

app.post("/make-server-d095746c/records", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    const userToken = c.req.header("X-User-Token");
    
    if (!authHeader) {
      return c.json({ error: "Authorization header required" }, 401);
    }
    
    const token = userToken || authHeader.split(" ")[1];
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') || '',
      Deno.env.get('SUPABASE_ANON_KEY') || '',
    );
    
    const { data: { user }, error } = await supabase.auth.getUser(token);
    
    if (error || !user) {
      return c.json({ error: "Invalid token" }, 401);
    }
    
    const { records } = await c.req.json();
    
    if (!Array.isArray(records)) {
      return c.json({ error: "Records must be an array" }, 400);
    }
    
    const key = `records_${user.id}`;
    await kv.set(key, JSON.stringify(records));
    
    return c.json({ success: true });
  } catch (err) {
    console.error("Server internal error:", err);
    return c.json({ error: err.message }, 500);
  }
});

Deno.serve(app.fetch);