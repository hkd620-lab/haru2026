import { useState, useEffect } from 'react';
import { useLocation } from 'react-router';
import { ChevronLeft, ChevronRight, Sparkles, X, Star, Info, Wand2, Settings } from 'lucide-react';
import { localDataService, HaruRecord } from '../services/localDataService';
import { useAuth } from '../contexts/AuthContext';
import { SayuTitleAnimation } from '../components/SayuTitleAnimation';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { GeminiService } from '../services/gemini';
import { toast } from 'sonner';

// --- API Key 관리 ---
const GEMINI_API_KEY_STORAGE_KEY = 'haru_gemini_api_key';

function getStoredApiKey(): string | null {
  try {
    return localStorage.getItem(GEMINI_API_KEY_STORAGE_KEY);
  } catch {
    return null;
  }
}

function setStoredApiKey(key: string) {
  try {
    localStorage.setItem(GEMINI_API_KEY_STORAGE_KEY, key);
  } catch {
    // ignore
  }
}
// --------------------

// SAYU 편집 모달
interface SayuModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: string;
  originalData?: Record<string, string>; // 원본 데이터 추가
  format?: string; // 어떤 형식인지 (일기, 에세이 등)
  dateLabel: string;
  currentRating?: number;
  onSave: (content: string, rating: number) => void;
}

function SayuModal({ isOpen, onClose, content, originalData, format, dateLabel, currentRating, onSave }: SayuModalProps) {
  const [editedContent, setEditedContent] = useState(content);
  const [isSaving, setIsSaving] = useState(false);
  const [rating, setRating] = useState(currentRating || 1);
  const [viewMode, setViewMode] = useState<'ai' | 'original'>('ai'); // 보기 모드 상태 추가

  useEffect(() => {
    if (isOpen) {
      setEditedContent(content);
      setRating(currentRating || 1);
      setViewMode('ai'); // 모달 열릴 때마다 AI 보기로 초기화
    }
  }, [isOpen, content, currentRating]);

  if (!isOpen) return null;

  const handleSave = async () => {
    setIsSaving(true);
    try {
      onSave(editedContent, rating);
      alert('✅ SAYU가 최종 저장되었습니다!');
      onClose();
    } catch (error) {
      console.error('저장 실패:', error);
      alert('❌ 저장에 실패했습니다. 다시 시도해주세요.');
    } finally {
      setIsSaving(false);
    }
  };

  // 원본 데이터 렌더링 헬퍼
  const renderOriginalData = () => {
    if (!originalData || Object.keys(originalData).length === 0) {
      return (
        <div style={{ padding: '40px', textAlign: 'center', color: '#999' }}>
          <p>저장된 원본 데이터가 없습니다.</p>
          <p style={{fontSize: '11px', marginTop: '8px'}}>
            (사유가 AI로만 생성되었거나, 원본이 저장되지 않았을 수 있습니다)
          </p>
        </div>
      );
    }

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {Object.entries(originalData).map(([key, value]) => {
            // 키를 사람이 읽기 좋게 변환 (diary_action -> Action)
            let displayLabel = key;
            if (key.includes('_')) {
              const parts = key.split('_');
              if (parts.length > 1) {
                // 두 번째 부분(action, good 등)을 사용하고 첫 글자 대문자화
                const label = parts[1];
                displayLabel = label.charAt(0).toUpperCase() + label.slice(1);
              }
            } else {
               // _가 없으면 그냥 첫 글자 대문자화
               displayLabel = key.charAt(0).toUpperCase() + key.slice(1);
            }
            
            return (
              <div key={key} style={{ backgroundColor: '#fff', padding: '16px', borderRadius: '8px', border: '1px solid #eee' }}>
                <span style={{ 
                  display: 'inline-block', 
                  fontSize: '11px', 
                  fontWeight: '600', 
                  color: '#1A3C6E', 
                  backgroundColor: '#F0F7FF', 
                  padding: '4px 8px', 
                  borderRadius: '4px',
                  marginBottom: '8px'
                }}>
                  {displayLabel}
                </span>
                <p style={{ margin: 0, fontSize: '14px', lineHeight: '1.6', color: '#333', whiteSpace: 'pre-wrap' }}>
                  {value}
                </p>
              </div>
            );
        })}
      </div>
    );
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        padding: '20px',
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: '#FAF9F6',
          borderRadius: 12,
          maxWidth: 800,
          width: '100%',
          maxHeight: '90vh',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          style={{
            padding: '24px',
            borderBottom: '1px solid #e5e5e5',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            backgroundColor: '#fff',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Sparkles style={{ width: 22, height: 22, color: '#1A3C6E' }} />
              <h2 style={{ fontSize: 20, color: '#1A3C6E', fontWeight: 600, margin: 0 }}>
                {viewMode === 'ai' ? `다듬은 글 (${dateLabel})` : `원본 기록 (${dateLabel})`}
              </h2>
            </div>
            
            {/* 탭 전환 버튼 */}
            <div style={{ display: 'flex', backgroundColor: '#f0f0f0', borderRadius: '6px', padding: '2px' }}>
              <button
                onClick={() => setViewMode('ai')}
                style={{
                  padding: '6px 12px',
                  fontSize: '12px',
                  fontWeight: 600,
                  border: 'none',
                  borderRadius: '4px',
                  backgroundColor: viewMode === 'ai' ? '#fff' : 'transparent',
                  color: viewMode === 'ai' ? '#1A3C6E' : '#666',
                  boxShadow: viewMode === 'ai' ? '0 1px 2px rgba(0,0,0,0.1)' : 'none',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
              >
                ✨ AI 글
              </button>
              <button
                onClick={() => setViewMode('original')}
                style={{
                  padding: '6px 12px',
                  fontSize: '12px',
                  fontWeight: 600,
                  border: 'none',
                  borderRadius: '4px',
                  backgroundColor: viewMode === 'original' ? '#fff' : 'transparent',
                  color: viewMode === 'original' ? '#1A3C6E' : '#666',
                  boxShadow: viewMode === 'original' ? '0 1px 2px rgba(0,0,0,0.1)' : 'none',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
              >
                📜 원본
              </button>
            </div>
          </div>

          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: 8,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <X style={{ width: 22, height: 22, color: '#666' }} />
          </button>
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '28px' }}>
          {viewMode === 'ai' ? (
            <>
              <p style={{ fontSize: 13, color: '#999', marginBottom: 12 }}>
                다듬어진 글을 자유롭게 편집하고 최종 저장하세요
              </p>
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                placeholder="내용을 입력하세요..."
                style={{
                  width: '100%',
                  minHeight: 400,
                  padding: '20px',
                  fontSize: 15,
                  border: '2px solid #1A3C6E',
                  borderRadius: 10,
                  backgroundColor: '#fff',
                  color: '#333',
                  resize: 'vertical',
                  fontFamily: 'inherit',
                  lineHeight: 1.9,
                  outline: 'none',
                }}
              />
            </>
          ) : (
             <>
              <p style={{ fontSize: 13, color: '#999', marginBottom: 12 }}>
                AI 다듬기 전, 사용자가 직접 입력한 기록입니다 (수정 불가)
              </p>
              <div style={{ 
                width: '100%', 
                minHeight: 400, 
                padding: '20px', 
                backgroundColor: '#FAF9F6', 
                borderRadius: '10px',
                border: '1px dashed #ccc',
                overflowY: 'auto'
              }}>
                {renderOriginalData()}
              </div>
             </>
          )}
        </div>

        {/* Rating */}
        <div
          style={{
            padding: '16px 28px',
            borderTop: '1px solid #e5e5e5',
            display: 'flex',
            alignItems: 'center',
            gap: 16,
            flexWrap: 'wrap',
            backgroundColor: '#fff',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
            <p style={{ fontSize: 13, color: '#1A3C6E', fontWeight: 600, margin: 0, whiteSpace: 'nowrap' }}>⭐ 오늘의 중요도</p>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                fill={star <= rating ? '#FFD700' : 'none'}
                style={{
                  width: 24,
                  height: 24,
                  color: star <= rating ? '#FFD700' : '#D1D5DB',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
                onClick={() => setRating(star)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'scale(1.15)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              />
            ))}
          </div>
          <p style={{ fontSize: 12, color: '#999', margin: 0 }}>({rating}/5)</p>
        </div>

        {/* Footer */}
        <div
          style={{
            padding: '20px 28px',
            borderTop: '1px solid #e5e5e5',
            display: 'flex',
            gap: 12,
            justifyContent: 'flex-end',
            backgroundColor: '#fff',
          }}
        >
          <button
            onClick={onClose}
            disabled={isSaving}
            style={{
              padding: '12px 26px',
              fontSize: 14,
              border: '1px solid #e5e5e5',
              borderRadius: 8,
              backgroundColor: '#fff',
              color: '#666',
              cursor: isSaving ? 'not-allowed' : 'pointer',
              opacity: isSaving ? 0.5 : 1,
              fontWeight: 500,
            }}
          >
            취소
          </button>
          <button
            onClick={handleSave}
            disabled={isSaving}
            style={{
              padding: '12px 26px',
              fontSize: 14,
              border: 'none',
              borderRadius: 8,
              backgroundColor: '#1A3C6E',
              color: '#FAF9F6',
              cursor: isSaving ? 'not-allowed' : 'pointer',
              opacity: isSaving ? 0.7 : 1,
              fontWeight: 600,
            }}
          >
            {isSaving ? '💾 저장 중...' : '💾 최종 저장'}
          </button>
        </div>
      </div>
    </div>
  );
}

export function SayuPage() {
  const { user: authUser } = useAuth();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [records, setRecords] = useState<HaruRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedRecord, setSelectedRecord] = useState<HaruRecord | null>(null);
  
  // AI 상태 관리
  const [isPolishing, setIsPolishing] = useState(false);
  const [apiKey, setApiKey] = useState<string | null>(getStoredApiKey());
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [tempApiKey, setTempApiKey] = useState('');

  const [sayuModalState, setSayuModalState] = useState<{
    isOpen: boolean;
    content: string;
    originalData?: Record<string, string>;
    dateLabel: string;
    currentRating: number;
  }>({ isOpen: false, content: '', dateLabel: '', currentRating: 1 });
  const [showSayuGuide, setShowSayuGuide] = useState(() => {
    try {
      const saved = localStorage.getItem('haru_sayu_guide_visible');
      return saved !== 'false';
    } catch {
      return true;
    }
  });

  const location = useLocation();

  useEffect(() => {
    fetchRecords();
  }, [location]);

  useEffect(() => {
    if (!loading && selectedDate) {
      const record = records.find((r) => r.date === selectedDate);
      setSelectedRecord(record || null);
    }
  }, [loading, records, selectedDate]);

  // 원본 데이터 수집 헬퍼 함수 (시스템 필드를 제외한 모든 사용자 입력 데이터 수집)
  const collectOriginalData = (record: HaruRecord): Record<string, string> => {
    const data: Record<string, string> = {};
    
    // 시스템에서 사용하는 필드 목록 (이것들을 제외하고 모두 가져옴)
    const systemFields = [
      'id', 'uid', 'date', 'weather', 'temperature', 'mood', 
      'formats', 'polished', 'polishedAt', 'sayuContent', 'sayuSavedAt', 
      'mergeRating', 'createdAt', 'updatedAt'
    ];

    if (!record) return data;

    try {
      Object.keys(record).forEach(key => {
          // 시스템 필드가 아닌 경우만 처리
          if (!systemFields.includes(key)) {
            const value = record[key];
            // 값이 있고 (null/undefined 아님)
            if (value !== null && value !== undefined) {
               // 문자열로 변환하여 저장
               const strValue = String(value).trim();
               // 너무 짧은 값이나(1자 미만) 객체 문자열([object Object]) 등은 제외할 수도 있지만,
               // 일단 사용자가 쓴 건 다 보여주는 게 안전함.
               if (strValue.length > 0 && strValue !== '[object Object]') {
                 data[key] = strValue;
               }
            }
          }
      });
    } catch (e) {
      console.error("Error collecting original data:", e);
    }

    return data;
  };

  const fetchRecords = () => {
    try {
      const uid = authUser.uid;
      const data = localDataService.getRecords(uid);
      setRecords(data);
    } catch (error) {
      console.error('기록 불러오기 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    return days;
  };

  const formatDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const hasSayu = (date: Date | null) => {
    if (!date) return false;
    const dateStr = formatDateString(date);
    const record = records.find((r) => r.date === dateStr);
    if (!record) return false;
    if (record.sayuSavedAt) return 'saved';      // 💙 최종 저장 완료
    if (record.polished) return 'polished';       // 🟡 다듬기 완료 (SAYU 편집 대기)
    return false;
  };

  const handleDateClick = (date: Date | null) => {
    if (!date) return;
    const dateStr = formatDateString(date);
    setSelectedDate(dateStr);
    const record = records.find((r) => r.date === dateStr);
    setSelectedRecord(record || null);

    // sayuSavedAt 또는 polished(다듬기 완료)인 경우 모두 모달 열기
    if (record && (record.sayuSavedAt || record.polished) && record.sayuContent) {
      const originalData = collectOriginalData(record);
      setSayuModalState({
        isOpen: true,
        content: record.sayuContent,
        originalData: originalData,
        dateLabel: new Date(dateStr + 'T00:00:00').toLocaleDateString('ko-KR', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          weekday: 'long',
        }),
        currentRating: record.mergeRating || 1,
      });
    }
  };

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const handleSayuButtonClick = async () => {
    if (!selectedRecord) return;

    // 이미 저장된 내용이 있으면 바로 모달 열기
    if (selectedRecord.sayuSavedAt && selectedRecord.sayuContent) {
      openSayuModal(selectedRecord.sayuContent, selectedRecord.mergeRating || 1);
      return;
    }

    // API 키 확인
    if (!apiKey) {
      setShowApiKeyInput(true);
      return;
    }

    // AI 다듬기 시작
    setIsPolishing(true);
    try {
      const gemini = new GeminiService(apiKey);
      // 기록의 형식이 없으면 기본값 'diary' 사용 (실제 앱에서는 선택된 형식 사용)
      // 현재 HaruRecord 타입 정의를 확인해야 함. 임시로 'diary'로 가정하거나 content에서 추론?
      // 로컬 데이터 서비스에 형식이 저장되어 있다고 가정. 없다면 'diary'
      const format = (selectedRecord as any).format || 'diary'; 
      
      const originalContent = selectedRecord.content;
      // originalContent가 없으면 포맷별 데이터라도 수집해야 함 (이 부분은 LibraryPage의 로직과 맞춰야 함)
      // LibraryPage에서 polish할 때 원본 데이터를 모두 합쳐서 보내므로,
      // 여기서 다시 polish를 요청할 때도 원본 데이터를 합쳐서 보내야 함.
      // 하지만 이미 polished된 상태라면 sayuContent가 있을 것이므로 이 분기는 '아직 polished 안된 상태'에서만 탈 것임.
      // LibraryPage에서 polished: true로 만들고 sayuContent를 저장하므로, 사실상 여기서는 openSayuModal만 호출될 가능성이 높음.
      // 만약 재요청이라면...
      
      // 여기서는 간단히 openSayuModal 호출로직만 수정. 실제 polish 로직은 LibraryPage가 담당.
      // 하지만 SayuPage에서도 'AI로 글 다듬기' 버튼이 있으므로 로직 필요.
      
      let textToPolish = '';
      const originalData = collectOriginalData(selectedRecord);
      
      if (Object.keys(originalData).length > 0) {
           textToPolish = Object.values(originalData).join('\n\n');
      } else if (selectedRecord.content) {
          textToPolish = selectedRecord.content;
      }

      if (!textToPolish.trim()) {
        toast.error('다듬을 내용이 없습니다.');
        setIsPolishing(false);
        return;
      }

      const polished = await gemini.polishContent(textToPolish, format);
      
      // 다듬어진 내용으로 모달 열기
      openSayuModal(polished, selectedRecord.mergeRating || 1);

    } catch (error: any) {
      console.error('AI Processing Failed:', error);
      const errorMessage = String(error);

      if (errorMessage.includes('SERVICE_DISABLED') || errorMessage.includes('Generative Language API')) {
        toast.error('구글 API가 활성화되지 않았습니다. Google Cloud Console에서 "Generative Language API"를 사용 설정해주세요.', { duration: 5000 });
      } else if (errorMessage.includes('400') || errorMessage.includes('403')) {
         toast.error('API 키가 올바르지 않거나 만료되었습니다. 다시 입력해주세요.');
         setApiKey(null);
         localStorage.removeItem(GEMINI_API_KEY_STORAGE_KEY);
         setShowApiKeyInput(true);
      } else {
        toast.error('AI 연결에 실패했습니다. 잠시 후 다시 시도해주세요.');
      }
    } finally {
      setIsPolishing(false);
    }
  };

  const openSayuModal = (content: string, rating: number) => {
    const originalData = selectedRecord ? collectOriginalData(selectedRecord) : {};
    setSayuModalState({
      isOpen: true,
      content,
      originalData,
      dateLabel: new Date(selectedDate! + 'T00:00:00').toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long',
      }),
      currentRating: rating,
    });
  };

  const saveApiKey = () => {
    if (tempApiKey.trim()) {
      setStoredApiKey(tempApiKey.trim());
      setApiKey(tempApiKey.trim());
      setShowApiKeyInput(false);
      toast.success('API 키가 저장되었습니다.');
    }
  };

  const handleSaveSayu = (content: string, rating: number) => {
    if (!selectedRecord) return;

    try {
      const updateData = {
        sayuContent: content,
        sayuSavedAt: new Date().toISOString(),
        mergeRating: rating,
      };
      localDataService.updateRecord(selectedRecord.id, updateData);

      const updated = { ...selectedRecord, ...updateData };
      setRecords((prev) => prev.map((r) => (r.id === selectedRecord.id ? updated : r)));
      setSelectedRecord(updated);
    } catch (error) {
      console.error('SAYU 저장 실패:', error);
      throw error;
    }
  };

  const handleModalClose = () => {
    setSayuModalState({ isOpen: false, content: '', dateLabel: '', currentRating: 1 });
  };

  const toggleSayuGuide = () => {
    const newValue = !showSayuGuide;
    setShowSayuGuide(newValue);
    try {
      localStorage.setItem('haru_sayu_guide_visible', String(newValue));
    } catch { /* ignore */ }
  };

  const days = getDaysInMonth(currentMonth);
  const monthName = currentMonth.toLocaleDateString('ko-KR', { year: 'numeric', month: 'long' });
  const showSayuButton = selectedRecord && (selectedRecord.content || selectedRecord.sayuContent); // 내용이 있거나 이미 다듬어진 경우 버튼 표시

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* API Key Input Modal */}
      {showApiKeyInput && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[1100] p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-bold text-[#1A3C6E] mb-2">Gemini API 키 입력</h3>
            <p className="text-sm text-gray-500 mb-4">
              AI 기능을 사용하려면 Google Gemini API 키가 필요합니다.<br/>
              (키는 브라우저에만 저장됩니다)
            </p>
            <input
              type="password"
              value={tempApiKey}
              onChange={(e) => setTempApiKey(e.target.value)}
              placeholder="AIzaSy..."
              className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:border-[#1A3C6E]"
            />
            <div className="flex justify-end gap-2">
              <button 
                onClick={() => setShowApiKeyInput(false)}
                className="px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg"
              >
                취소
              </button>
              <button 
                onClick={saveApiKey}
                className="px-4 py-2 bg-[#1A3C6E] text-white rounded-lg hover:opacity-90"
              >
                저장하고 시작하기
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-4 text-center">
              <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="underline hover:text-[#1A3C6E]">
                API 키 발급받기 (Google AI Studio)
              </a>
            </p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-2">
          <SayuTitleAnimation />
           {/* API Key 설정 버튼 (작게) */}
           <button 
            onClick={() => setShowApiKeyInput(true)}
            className="p-2 text-gray-400 hover:text-[#1A3C6E] transition-colors"
            title="API Key 설정"
          >
            <Settings size={18} />
          </button>
        </div>
        <div
          className="bg-purple-50 border-l-4 border-purple-600 rounded transition-all"
          style={{
            backgroundColor: '#F8F5FF',
            borderColor: '#1A3C6E',
            overflow: 'hidden',
          }}
        >
          <div
            className="flex items-center justify-between p-3 cursor-pointer hover:bg-opacity-80 transition-colors"
            onClick={toggleSayuGuide}
            style={{ backgroundColor: showSayuGuide ? 'transparent' : 'rgba(26, 60, 110, 0.05)' }}
          >
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4" style={{ color: '#1A3C6E' }} />
              <p className="text-xs font-semibold" style={{ color: '#1A3C6E', margin: 0 }}>
                사용 안내
              </p>
            </div>
            <div
              className="text-xs transition-transform"
              style={{
                color: '#1A3C6E',
                transform: showSayuGuide ? 'rotate(180deg)' : 'rotate(0deg)',
              }}
            >
              ▼
            </div>
          </div>
          {showSayuGuide && (
            <div className="px-3 pb-3">
              <p className="text-xs leading-relaxed" style={{ color: '#1A3C6E' }}>
                📅 <strong>점이 있는 날짜</strong>를 누르면 글을 다시 열고 수정할 수 있습니다.
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Content Section */}
        <div className="flex-1 order-2 lg:order-1">
          {loading ? (
            <div className="bg-white rounded-lg p-8 shadow-sm text-center">
              <p style={{ color: '#999' }}>불러오는 중...</p>
            </div>
          ) : selectedRecord ? (
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg mb-4" style={{ color: '#1A3C6E' }}>
                {new Date(selectedDate! + 'T00:00:00').toLocaleDateString('ko-KR', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  weekday: 'long',
                })}
              </h3>

              {/* 날씨/기온/기분 */}
              {(selectedRecord.weather || selectedRecord.temperature || selectedRecord.mood) && (
                <div className="flex gap-2 mb-5 flex-wrap">
                  {selectedRecord.weather && (
                    <span
                      className="px-3 py-1 rounded-full text-xs"
                      style={{ backgroundColor: '#FAF9F6', color: '#1A3C6E', border: '1px solid #e5e5e5' }}
                    >
                      날씨: {selectedRecord.weather}
                    </span>
                  )}
                  {selectedRecord.temperature && (
                    <span
                      className="px-3 py-1 rounded-full text-xs"
                      style={{ backgroundColor: '#FAF9F6', color: '#1A3C6E', border: '1px solid #e5e5e5' }}
                    >
                      기온: {selectedRecord.temperature}
                    </span>
                  )}
                  {selectedRecord.mood && (
                    <span
                      className="px-3 py-1 rounded-full text-xs"
                      style={{ backgroundColor: '#FAF9F6', color: '#1A3C6E', border: '1px solid #e5e5e5' }}
                    >
                      기분: {selectedRecord.mood}
                    </span>
                  )}
                </div>
              )}

              {/* SAYU 피아노 버튼 */}
              {showSayuButton && (
                <div className="mb-6">
                  <p className="text-xs mb-3 font-medium" style={{ color: '#999' }}>
                    {selectedRecord.sayuSavedAt
                      ? 'SAYU를 언제든지 다시 편집할 수 있습니다'
                      : 'AI가 다듬은 글을 편집하여 SAYU를 완성하세요'}
                  </p>
                  <button
                    onClick={handleSayuButtonClick}
                    disabled={isPolishing}
                    className="w-full px-8 rounded-xl text-base transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed"
                    style={{
                      paddingTop: '16px',
                      paddingBottom: '16px',
                      backgroundColor: '#1A3C6E',
                      color: '#FAF9F6',
                      border: '4px solid rgba(255, 255, 255, 0.3)',
                      borderBottomWidth: '8px',
                      boxShadow: '0 6px 0 rgba(0, 0, 0, 0.15), 0 8px 20px rgba(26, 60, 110, 0.3)',
                      fontWeight: 700,
                      letterSpacing: '0.08em',
                      textShadow: '0 1px 2px rgba(0, 0, 0, 0.2)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px'
                    }}
                  >
                    {isPolishing ? (
                      <>
                        <Wand2 className="animate-spin" size={20} />
                        AI가 글을 다듬는 중...
                      </>
                    ) : (
                      <>
                        <span>🎹</span>
                        {selectedRecord.sayuSavedAt ? '수정' : 'AI로 글 다듬기'} (
                        {new Date(selectedDate! + 'T00:00:00').toLocaleDateString('ko-KR', {
                          month: 'long',
                          day: 'numeric',
                        })}
                        )
                      </>
                    )}
                  </button>
                </div>
              )}

              {/* SAYU 저장 완료 */}
              {selectedRecord.sayuSavedAt && (
                <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: '#F0F7F4', border: '2px solid #1A3C6E' }}>
                  <p className="text-sm font-semibold" style={{ color: '#1A3C6E' }}>
                    ✅ SAYU 저장 완료
                  </p>
                  <p className="text-xs mt-1" style={{ color: '#666' }}>
                    저장 시간:{' '}
                    {new Date(selectedRecord.sayuSavedAt).toLocaleString('ko-KR', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              )}

              {/* 다듬기 안 된 경우 안내 */}
              {!selectedRecord.polished && (
                <div className="p-6 rounded-lg text-center" style={{ backgroundColor: '#FAF9F6', border: '1px solid #e5e5e5' }}>
                  <Sparkles className="w-12 h-12 mx-auto mb-3" style={{ color: '#1A3C6E', opacity: 0.5 }} />
                  <p className="text-sm mb-2" style={{ color: '#666' }}>
                    아직 다듬기가 완료되지 않았습니다
                  </p>
                  <p className="text-xs" style={{ color: '#999' }}>
                    서재 페이지에서 모든 형식을 작성하고 다듬기를 완료하세요
                  </p>
                </div>
              )}
            </div>
          ) : selectedDate ? (
            <div className="bg-white rounded-lg p-8 shadow-sm text-center">
              <p style={{ color: '#999' }}>이 날짜에는 기록이 없습니다</p>
            </div>
          ) : (
            <div className="bg-white rounded-lg p-8 shadow-sm text-center">
              <p style={{ color: '#999' }}>달력에서 날짜를 선택하세요</p>
            </div>
          )}
        </div>

        {/* Compact Calendar Section */}
        <div className="w-[80%] mx-auto lg:mx-0 lg:w-[168px] order-1 lg:order-2">
          <section className="bg-white rounded-lg p-2 lg:p-3 shadow-sm">
            <div className="flex items-center justify-between mb-1 lg:mb-2">
              <button
                onClick={handlePrevMonth}
                className="p-1 lg:p-1.5 rounded hover:bg-gray-50 transition-all"
                style={{ color: '#1A3C6E' }}
              >
                <ChevronLeft className="w-3 h-3 lg:w-5 lg:h-5" />
              </button>
              <h2 className="text-[9px] lg:text-sm tracking-wide font-medium" style={{ color: '#333333' }}>
                {monthName}
              </h2>
              <button
                onClick={handleNextMonth}
                className="p-1 lg:p-1.5 rounded hover:bg-gray-50 transition-all"
                style={{ color: '#1A3C6E' }}
              >
                <ChevronRight className="w-3 h-3 lg:w-5 lg:h-5" />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-0.5 lg:gap-1">
              {['일', '월', '화', '수', '목', '금', '토'].map((day, index) => (
                <div
                  key={day}
                  className="text-center text-[8px] lg:text-xs py-0.5 lg:py-1"
                  style={{ color: index === 0 ? '#1A3C6E' : '#999999' }}
                >
                  {day}
                </div>
              ))}

              {days.map((day, index) => {
                const sayuStatus = hasSayu(day);
                const isSelected = day && selectedDate === formatDateString(day);

                return (
                  <button
                    key={index}
                    onClick={() => handleDateClick(day)}
                    disabled={!day}
                    className="relative aspect-square flex items-center justify-center rounded transition-all disabled:cursor-default hover:bg-gray-50"
                    style={{
                      backgroundColor: isSelected ? '#1A3C6E' : 'transparent',
                      color: !day ? 'transparent' : isSelected ? '#FAF9F6' : '#333333',
                      fontSize: '11px',
                      fontWeight: 600,
                    }}
                  >
                    {day && day.getDate()}
                    {sayuStatus === 'saved' && (
                      <div
                        className="absolute bottom-0.5 w-3 h-3 rounded-full"
                        style={{
                          backgroundColor: isSelected ? '#FAF9F6' : '#1A3C6E',
                          boxShadow: isSelected ? 'none' : '0 0 0 2px rgba(26,60,110,0.25)',
                        }}
                      />
                    )}
                    {sayuStatus === 'polished' && (
                      <div
                        className="absolute bottom-0.5 w-3 h-3 rounded-full"
                        style={{
                          backgroundColor: '#F59E0B',
                          boxShadow: '0 0 0 2px rgba(245,158,11,0.3)',
                        }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          {/* Legend */}
          <div className="mt-1 lg:mt-2 flex flex-col gap-1 text-[9px] lg:text-xs" style={{ color: '#999' }}>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: '#1A3C6E', boxShadow: '0 0 0 2px rgba(26,60,110,0.25)' }} />
              <span>SAYU 저장</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: '#F59E0B', boxShadow: '0 0 0 2px rgba(245,158,11,0.3)' }} />
              <span>다듬기 완료</span>
            </div>
          </div>
        </div>
      </div>

      {/* SAYU Modal */}
      <SayuModal
        isOpen={sayuModalState.isOpen}
        onClose={handleModalClose}
        content={sayuModalState.content}
        dateLabel={sayuModalState.dateLabel}
        currentRating={sayuModalState.currentRating}
        onSave={handleSaveSayu}
      />
    </div>
  );
}