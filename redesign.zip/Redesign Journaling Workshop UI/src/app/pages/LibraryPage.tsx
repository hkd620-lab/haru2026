import { useState, useEffect } from 'react';
import { BookOpen, Info, Settings, Wand2 } from 'lucide-react';
import { FormatModal } from '../components/FormatModal';
import { useLocation, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { localDataService, HaruRecord, RecordFormat } from '../services/localDataService';
import { LibraryTitleAnimation } from '../components/LibraryTitleAnimation';
import { GeminiService } from '../services/gemini';
import { toast } from 'sonner';

// --- API Key 관리 (SayuPage와 동일) ---
const GEMINI_API_KEY_STORAGE_KEY = 'haru_gemini_api_key';

function getStoredApiKey(): string | null {
  try {
    return localStorage.getItem(GEMINI_API_KEY_STORAGE_KEY);
  } catch {
    return null;
  }
}

function setStoredApiKey(key: string) {
  try {
    localStorage.setItem(GEMINI_API_KEY_STORAGE_KEY, key);
  } catch {
    // ignore
  }
}
// --------------------

export function LibraryPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user: authUser } = useAuth();
  const [records, setRecords] = useState<HaruRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState<HaruRecord | null>(null);
  
  // AI 상태 관리
  const [apiKey, setApiKey] = useState<string | null>(getStoredApiKey());
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [tempApiKey, setTempApiKey] = useState('');
  
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    format: RecordFormat | null;
  }>({ isOpen: false, format: null });
  const [polishModalOpen, setPolishModalOpen] = useState(false);
  const [polishedContent, setPolishedContent] = useState('');
  const [isPolishing, setIsPolishing] = useState(false);
  const [showLibraryGuide, setShowLibraryGuide] = useState(() => {
    try {
      const saved = localStorage.getItem('haru_library_guide_visible');
      return saved !== 'false';
    } catch {
      return true;
    }
  });

  const locationState = location.state as { savedDate?: string; justSaved?: boolean } | null;

  useEffect(() => {
    fetchRecords();
  }, [authUser?.uid, location]);

  // 기록을 불러온 후 오늘 날짜 기록 자동 선택
  useEffect(() => {
    if (!loading) {
      const todayStr = formatDateString(new Date());
      const todayRecord = records.find((r) => r.date === todayStr);
      setSelectedRecord(todayRecord || null);
    }
  }, [loading, records]);

  const toggleLibraryGuide = () => {
    const newValue = !showLibraryGuide;
    setShowLibraryGuide(newValue);
    try {
      localStorage.setItem('haru_library_guide_visible', String(newValue));
    } catch { /* ignore */ }
  };

  const fetchRecords = () => {
    setLoading(true);
    try {
      const uid = authUser.uid;
      const data = localDataService.getRecords(uid);
      setRecords(data);
    } catch (error) {
      console.error('기록 불러오기 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const handleFormatClick = (format: RecordFormat) => {
    setModalState({ isOpen: true, format });
  };

  const handleModalClose = () => {
    setModalState({ isOpen: false, format: null });
  };

  const handleSaveFormatData = async (formatData: Record<string, string>) => {
    if (!selectedRecord) return;

    const filteredData: Record<string, string> = {};
    Object.entries(formatData).forEach(([key, value]) => {
      if (value && value.trim().length > 0) {
        filteredData[key] = value;
      }
    });

    if (Object.keys(filteredData).length === 0) {
      alert('⚠️ 최소 1개 이상의 필드를 작성해주세요.');
      return;
    }

    try {
      localDataService.updateRecord(selectedRecord.id, filteredData);

      // 로컬 상태 업데이트
      const updated = { ...selectedRecord, ...filteredData };
      setRecords((prev) => prev.map((r) => (r.id === selectedRecord.id ? updated : r)));
      setSelectedRecord(updated);

      alert('✅ 저장되었습니다!');
    } catch (error) {
      console.error('저장 실패:', error);
      alert('❌ 저장에 실패했습니다. 다시 시도해주세요.');
      throw error;
    }
  };

  // 형식별 데이터 추출
  const getFormatData = (format: RecordFormat) => {
    if (!selectedRecord) return {};
    const prefix =
      format === '일기' ? 'diary_' :
      format === '에세이' ? 'essay_' :
      format === '선교보고' ? 'mission_' :
      format === '일반보고' ? 'report_' :
      format === '업무일지' ? 'work_' : 'travel_';

    const data: Record<string, string> = {};
    Object.keys(selectedRecord).forEach((key) => {
      if (key.startsWith(prefix)) {
        data[key] = selectedRecord[key];
      }
    });
    return data;
  };

  // 모든 형식이 작성되었는지 확인
  const checkAllFormatsCompleted = () => {
    if (!selectedRecord || !selectedRecord.formats || selectedRecord.formats.length === 0) {
      return false;
    }
    return selectedRecord.formats.every((format: RecordFormat) => {
      const formatData = getFormatData(format);
      const dataKeys = Object.keys(formatData);
      return dataKeys.length > 0 && dataKeys.some((key) => {
        const value = formatData[key];
        return value && typeof value === 'string' && value.trim().length > 0;
      });
    });
  };

  const allFormatsCompleted = selectedRecord ? checkAllFormatsCompleted() : false;

  const saveApiKey = () => {
    if (tempApiKey.trim()) {
      setStoredApiKey(tempApiKey.trim());
      setApiKey(tempApiKey.trim());
      setShowApiKeyInput(false);
      toast.success('API 키가 저장되었습니다.');
    }
  };

  // AI 다듬기 (Gemini 연동)
  const handlePolish = async () => {
    if (!selectedRecord) return;

    // API 키 확인
    if (!apiKey) {
      setShowApiKeyInput(true);
      return;
    }

    setIsPolishing(true);

    try {
      const gemini = new GeminiService(apiKey);
      
      // 기록 데이터 수집
      let allContent = '';
      selectedRecord.formats?.forEach((format: RecordFormat) => {
        const formatData = getFormatData(format);
        const contentValues = Object.values(formatData).filter(v => v && v.trim()).join('\n');
        if (contentValues) {
          allContent += `[${format}]\n${contentValues}\n\n`;
        }
      });

      if (!allContent.trim()) {
        toast.error('다듬을 내용이 충분하지 않습니다.');
        setIsPolishing(false);
        return;
      }

      // 하루 기록 종합 다듬기 요청 (Aggregation 기능 활용 또는 별도 로직)
      // 여기서는 'diary' 모드를 기본으로 사용하되, 시스템 프롬프트에 종합 요청을 포함하거나
      // GeminiService에 새로운 메서드를 추가할 수도 있음.
      // 일단은 'diary' 형식을 활용하여 "하루 기록 종합" 느낌으로 요청
      
      // 임시로 diary 형식으로 요청하되, 내용은 합쳐진 내용
      // 더 정교하게 하려면 GeminiService에 'daily_summary' 같은 타입을 추가하는 것이 좋음
      // 여기서는 기존 polishContent 사용
      const polished = await gemini.polishContent(
        `다음은 하루 동안 작성된 여러 형식의 기록들입니다. 이를 종합하여 하나의 자연스러운 글로 다듬어주세요.\n\n${allContent}`, 
        'diary' // 하루 기록이므로 일기 형식 모델 사용
      );

      setPolishedContent(polished);
      setPolishModalOpen(true);
    } catch (error: any) {
      console.error('AI Processing Failed:', error);
      const errorMessage = String(error);

      if (errorMessage.includes('SERVICE_DISABLED') || errorMessage.includes('Generative Language API')) {
        toast.error('구글 API가 활성화되지 않았습니다. Google Cloud Console에서 "Generative Language API"를 사용 설정해주세요.', { duration: 5000 });
      } else if (errorMessage.includes('400') || errorMessage.includes('403')) {
         toast.error('API 키가 올바르지 않거나 만료되었습니다. 다시 입력해주세요.');
         setApiKey(null);
         localStorage.removeItem(GEMINI_API_KEY_STORAGE_KEY);
         setShowApiKeyInput(true);
      } else {
        toast.error('AI 연결에 실패했습니다. 잠시 후 다시 시도해주세요.');
      }
    } finally {
      setIsPolishing(false);
    }
  };

  // 다듬기 완료 처리
  const handlePolishComplete = () => {
    if (!selectedRecord) return;

    try {
      const updateData = {
        polished: true,
        polishedAt: new Date().toISOString(),
        sayuContent: polishedContent,
      };
      localDataService.updateRecord(selectedRecord.id, updateData);

      const updated = { ...selectedRecord, ...updateData };
      setRecords((prev) => prev.map((r) => (r.id === selectedRecord.id ? updated : r)));
      setSelectedRecord(updated);

      setPolishModalOpen(false);
      alert('✅ 다듬기가 완료되었습니다! SAYU 페이지로 이동합니다.');
      navigate('/sayu');
    } catch (error) {
      console.error('❌ 다듬기 완료 처리 실패:', error);
      alert('오류가 발생했습니다.');
    }
  };

  // 다듬기 초기화
  const handleResetPolish = () => {
    if (!selectedRecord) return;
    if (!confirm('다듬기를 초기화하시겠습니까?')) return;

    try {
      const updateData = {
        polished: false,
        polishedAt: null,
        sayuContent: null,
        sayuSavedAt: null,
      };
      localDataService.updateRecord(selectedRecord.id, updateData);

      const updated = { ...selectedRecord, ...updateData };
      setRecords((prev) => prev.map((r) => (r.id === selectedRecord.id ? updated : r)));
      setSelectedRecord(updated);

      alert('다듬기가 초기화되었습니다!');
    } catch (error) {
      console.error('초기화 실패:', error);
      alert('초기화에 실패했습니다.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      {/* API Key Input Modal */}
      {showApiKeyInput && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[1100] p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-lg font-bold text-[#1A3C6E] mb-2">Gemini API 키 입력</h3>
            <p className="text-sm text-gray-500 mb-4">
              AI 기능을 사용하려면 Google Gemini API 키가 필요합니다.<br/>
              (키는 브라우저에만 저장됩니다)
            </p>
            <input
              type="password"
              value={tempApiKey}
              onChange={(e) => setTempApiKey(e.target.value)}
              placeholder="AIzaSy..."
              className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:border-[#1A3C6E]"
            />
            <div className="flex justify-end gap-2">
              <button 
                onClick={() => setShowApiKeyInput(false)}
                className="px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg"
              >
                취소
              </button>
              <button 
                onClick={saveApiKey}
                className="px-4 py-2 bg-[#1A3C6E] text-white rounded-lg hover:opacity-90"
              >
                저장하고 시작하기
              </button>
            </div>
             <p className="text-xs text-gray-400 mt-4 text-center">
              <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="underline hover:text-[#1A3C6E]">
                API 키 발급받기 (Google AI Studio)
              </a>
            </p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-2">
          <LibraryTitleAnimation />
          <div className="flex gap-2 self-start mt-1 ml-auto">
             <button 
              onClick={() => setShowApiKeyInput(true)}
              className="p-1.5 text-gray-400 hover:text-[#1A3C6E] transition-colors rounded-full hover:bg-gray-100"
              title="API Key 설정"
            >
              <Settings size={18} />
            </button>
            <button
              onClick={fetchRecords}
              className="text-xs px-3 py-1.5 rounded-lg transition-all hover:opacity-80"
              style={{
                backgroundColor: '#F0F7FF',
                color: '#1A3C6E',
                border: '1px solid #d0dff0',
              }}
            >
              🔄 새로고침
            </button>
          </div>
        </div>
        <p className="text-sm mb-2" style={{ color: '#666666' }}>
          오늘의 기록을 작성하세요
        </p>
        {/* 사용 안내 */}
        <div
          className="bg-blue-50 border-l-4 border-blue-600 rounded transition-all"
          style={{
            backgroundColor: '#F0F7FF',
            borderColor: '#1A3C6E',
            overflow: 'hidden',
          }}
        >
          <div
            className="flex items-center justify-between p-3 cursor-pointer hover:bg-opacity-80 transition-colors"
            onClick={toggleLibraryGuide}
            style={{ backgroundColor: showLibraryGuide ? 'transparent' : 'rgba(26, 60, 110, 0.05)' }}
          >
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4" style={{ color: '#1A3C6E' }} />
              <p className="text-xs font-semibold" style={{ color: '#1A3C6E', margin: 0 }}>
                사용 안내
              </p>
            </div>
            <div
              className="text-xs transition-transform"
              style={{
                color: '#1A3C6E',
                transform: showLibraryGuide ? 'rotate(180deg)' : 'rotate(0deg)',
              }}
            >
              ▼
            </div>
          </div>
          {showLibraryGuide && (
            <div className="px-3 pb-3">
              <p className="text-xs leading-relaxed" style={{ color: '#1A3C6E' }}>
                💡 여기는 새 글 작성 공간입니다. 저장된 글 수정은{' '}
                <strong>사유(SAYU) 달력</strong>에서 합니다.
              </p>
              <p className="text-xs mt-1 leading-relaxed" style={{ color: '#666' }}>
                과거 글도 SAYU에서 편집하세요.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      {loading ? (
        <div className="bg-white rounded-lg p-8 shadow-sm text-center">
          <p style={{ color: '#999' }}>불러오는 중...</p>
        </div>
      ) : selectedRecord ? (
        <div className="space-y-4">
          {/* 날짜 헤더 */}
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="text-base font-semibold" style={{ color: '#1A3C6E' }}>
              {new Date(selectedRecord.date + 'T00:00:00').toLocaleDateString('ko-KR', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                weekday: 'long',
              })}
            </h3>
          </div>

          {/* 날씨/기온/기분 */}
          {(selectedRecord.weather || selectedRecord.temperature || selectedRecord.mood) && (
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <p className="text-xs mb-2 font-medium" style={{ color: '#999' }}>
                오늘의 환경
              </p>
              <div className="flex gap-2 flex-wrap">
                {selectedRecord.weather && (
                  <span
                    className="px-4 py-2 rounded-lg text-sm font-medium"
                    style={{ backgroundColor: '#F0F7FF', color: '#1A3C6E', border: '1px solid #d0dff0' }}
                  >
                    날씨: {selectedRecord.weather}
                  </span>
                )}
                {selectedRecord.temperature && (
                  <span
                    className="px-4 py-2 rounded-lg text-sm font-medium"
                    style={{ backgroundColor: '#F0F7FF', color: '#1A3C6E', border: '1px solid #d0dff0' }}
                  >
                    기온: {selectedRecord.temperature}
                  </span>
                )}
                {selectedRecord.mood && (
                  <span
                    className="px-4 py-2 rounded-lg text-sm font-medium"
                    style={{ backgroundColor: '#F0F7FF', color: '#1A3C6E', border: '1px solid #d0dff0' }}
                  >
                    기분: {selectedRecord.mood}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* 피아노 버튼 */}
          {selectedRecord.formats && selectedRecord.formats.length > 0 ? (
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <p className="text-xs mb-3 font-medium" style={{ color: '#999' }}>
                🎹 기록 형식을 클릭하면 작성 화면이 열립니다
              </p>
              <div className="flex gap-2 flex-wrap">
                {selectedRecord.formats.map((format: RecordFormat) => (
                  <button
                    key={format}
                    onClick={() => handleFormatClick(format)}
                    className="px-6 py-3 rounded-lg text-sm transition-all hover:opacity-90 hover:shadow-lg shadow-md"
                    style={{
                      backgroundColor: '#1A3C6E',
                      color: '#FAF9F6',
                      border: '3px solid #2A4C7E',
                      fontWeight: 600,
                      letterSpacing: '0.05em',
                    }}
                  >
                    🎹 {format}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <p className="text-sm text-center" style={{ color: '#999' }}>
                선택된 형식이 없습니다
              </p>
            </div>
          )}

          {/* 다듬기 버튼 */}
          {allFormatsCompleted && !selectedRecord.polished && (
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <button
                onClick={handlePolish}
                disabled={isPolishing}
                className="w-full flex items-center justify-center gap-3 px-8 py-4 rounded-lg text-base transition-all hover:opacity-90 shadow-lg"
                style={{
                  backgroundColor: '#1A3C6E',
                  color: '#FAF9F6',
                  fontWeight: 600,
                  letterSpacing: '0.05em',
                  opacity: isPolishing ? 0.7 : 1,
                }}
              >
                 {isPolishing ? <Wand2 className="animate-spin" size={20} /> : <Wand2 size={20} />}
                <span>{isPolishing ? 'AI가 다듬는 중...' : '✨ AI로 다듬기'}</span>
              </button>
              <p className="text-xs text-center mt-3" style={{ color: '#999' }}>
                모든 형식 작성이 완료되었습니다! AI가 내용을 다듬어드립니다.
              </p>
            </div>
          )}

          {/* 다듬기 완료 표시 */}
          {selectedRecord.polished && (
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div
                className="w-full flex items-center justify-center gap-3 px-8 py-4 rounded-lg text-base"
                style={{
                  backgroundColor: '#F0F7F4',
                  color: '#1A3C6E',
                  fontWeight: 600,
                  letterSpacing: '0.05em',
                  border: '2px solid #1A3C6E',
                }}
              >
                <span>✅ 다듬기 완료</span>
              </div>
              <p className="text-xs text-center mt-3" style={{ color: '#999' }}>
                이 날짜의 기록이 완성되었습니다! SAYU 페이지에서 확인하세요.
              </p>
              <button
                onClick={handleResetPolish}
                className="w-full mt-4 px-6 py-3 rounded-lg text-sm transition-all hover:opacity-80"
                style={{
                  backgroundColor: '#f0f0f0',
                  color: '#666',
                  border: '1px solid #e5e5e5',
                  fontWeight: 500,
                }}
              >
                🔄 다듬기 초기화 (테스트용)
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-lg p-8 shadow-sm text-center">
          <div className="max-w-md mx-auto">
            <div className="mb-4">
              <BookOpen className="w-12 h-12 mx-auto mb-3" style={{ color: '#1A3C6E', opacity: 0.3 }} />
            </div>
            <p className="text-base mb-2" style={{ color: '#333' }}>오늘 기록이 없습니다</p>
            <p className="text-xs mb-6" style={{ color: '#999' }}>
              기록 페이지에서 오늘의 환경과 형식을 선택하세요
            </p>
            <button
              onClick={() => navigate('/record')}
              className="px-8 py-3 rounded-lg text-sm transition-all hover:opacity-90 shadow-md"
              style={{
                backgroundColor: '#1A3C6E',
                color: '#FAF9F6',
                fontWeight: 600,
                letterSpacing: '0.05em',
              }}
            >
              📝 기록 시작하기
            </button>
          </div>
        </div>
      )}

      {/* Format Modal */}
      {modalState.isOpen && modalState.format && selectedRecord && (
        <FormatModal
          isOpen={modalState.isOpen}
          onClose={handleModalClose}
          format={modalState.format}
          recordId={selectedRecord.id}
          // 다듬기가 완료된(polished) 상태라면 초기 데이터를 비워서 전달 -> 모달이 예시 문장을 보여줌
          // 그렇지 않으면 기존 작성 데이터를 전달 -> 수정 가능
          initialData={selectedRecord.polished ? {} : getFormatData(modalState.format)}
          onSave={handleSaveFormatData}
        />
      )}

      {/* Polish Modal */}
      {polishModalOpen && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: '20px',
          }}
          onClick={() => setPolishModalOpen(false)}
        >
          <div
            style={{
              backgroundColor: '#FAF9F6',
              borderRadius: 12,
              maxWidth: 700,
              width: '100%',
              maxHeight: '85vh',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              style={{
                padding: '24px',
                borderBottom: '1px solid #e5e5e5',
                backgroundColor: '#fff',
              }}
            >
              <h2 style={{ fontSize: 20, color: '#1A3C6E', fontWeight: 600, margin: 0 }}>
                ✨ AI가 다듬은 글
              </h2>
              <p style={{ fontSize: 13, color: '#999', marginTop: 8, marginBottom: 0 }}>
                여러 형식의 내용이 자연스럽게 재구성되었습니다
              </p>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
              <div
                style={{
                  backgroundColor: '#fff',
                  padding: '20px',
                  borderRadius: 8,
                  border: '1px solid #e5e5e5',
                  whiteSpace: 'pre-wrap',
                  fontSize: 14,
                  lineHeight: 1.8,
                  color: '#333',
                }}
              >
                {polishedContent}
              </div>
            </div>

            <div
              style={{
                padding: '20px 24px',
                borderTop: '1px solid #e5e5e5',
                display: 'flex',
                gap: 12,
                justifyContent: 'flex-end',
                backgroundColor: '#fff',
              }}
            >
              <button
                onClick={() => setPolishModalOpen(false)}
                style={{
                  padding: '12px 24px',
                  fontSize: 14,
                  border: '1px solid #e5e5e5',
                  borderRadius: 8,
                  backgroundColor: '#fff',
                  color: '#666',
                  cursor: 'pointer',
                  fontWeight: 500,
                }}
              >
                취소
              </button>
              <button
                onClick={handlePolishComplete}
                style={{
                  padding: '12px 32px',
                  fontSize: 15,
                  border: 'none',
                  borderRadius: 8,
                  backgroundColor: '#1A3C6E',
                  color: '#FAF9F6',
                  cursor: 'pointer',
                  fontWeight: 600,
                  letterSpacing: '0.05em',
                }}
              >
                💾 최종 저장 (SAYU로 이동)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}