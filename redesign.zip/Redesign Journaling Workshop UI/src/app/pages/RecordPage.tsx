import { useState } from 'react';
import { Calendar, Library } from 'lucide-react';
import { useNavigate } from 'react-router';
import { localDataService, RecordFormat } from '../services/localDataService';
import { useAuth } from '../contexts/AuthContext';

type Mood = '기쁨' | '평온' | '무미' | '울적' | '번잡';
type Weather = '쾌청' | '흐림' | '강우' | '굳음';
type Temperature = '폭염' | '온난' | '쾌적' | '쌀쌀' | '혹한';

const weatherOptions: Weather[] = ['쾌청', '흐림', '강우', '굳음'];
const temperatureOptions: Temperature[] = ['폭염', '온난', '쾌적', '쌀쌀', '혹한'];
const moodOptions: Mood[] = ['기쁨', '평온', '무미', '울적', '번잡'];
const formatOptions: RecordFormat[] = ['일기', '에세이', '선교보고', '일반보고', '업무일지', '여행기록'];

export function RecordPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [currentDate] = useState(new Date());
  const [mood, setMood] = useState<Mood>('평온');
  const [weather, setWeather] = useState<Weather>('쾌청');
  const [temperature, setTemperature] = useState<Temperature>('쾌적');
  const [selectedFormats, setSelectedFormats] = useState<RecordFormat[]>([]);
  const [content, setContent] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const formatDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const days = ['일', '월', '화', '수', '목', '금', '토'];
    const dayOfWeek = days[date.getDay()];
    return `${year}.${month}.${day} ${dayOfWeek}요일`;
  };

  const getLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const toggleFormat = (format: RecordFormat) => {
    if (selectedFormats.includes(format)) {
      setSelectedFormats(selectedFormats.filter((f) => f !== format));
    } else if (selectedFormats.length < 3) {
      setSelectedFormats([...selectedFormats, format]);
    }
  };

  const handleSave = () => {
    if (selectedFormats.length === 0) {
      alert('최소 1개의 형식을 선택해주세요.');
      return;
    }

    if (!content.trim()) {
      alert('오늘의 기록을 작성해주세요.');
      return;
    }

    if (!user) {
      alert('로그인이 필요합니다.');
      navigate('/login');
      return;
    }

    setIsSaving(true);
    try {
      const dateStr = getLocalDateString(currentDate);
      const uid = user.uid;

      localDataService.upsertRecord(uid, dateStr, {
        weather,
        temperature,
        mood,
        formats: selectedFormats,
        content: content,
      });

      alert('기록이 저장되었습니다!');

      setTimeout(() => {
        navigate('/library', {
          state: {
            savedDate: dateStr,
            justSaved: true,
          },
        });
      }, 300);
    } catch (error) {
      console.error('저장 실패:', error);
      alert('기록 저장에 실패했습니다.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
      <div className="space-y-4 md:space-y-5">
        {/* Date */}
        <section className="flex items-center justify-center gap-3 py-2 md:py-3">
          <Calendar className="w-4 h-4" style={{ color: '#1A3C6E' }} />
          <span className="text-sm md:text-base tracking-wide" style={{ color: '#333333' }}>
            {formatDate(currentDate)}
          </span>
        </section>

        {/* Context Section */}
        <section className="bg-white rounded-lg p-4 md:p-5 shadow-sm">
          <h2 className="text-xs md:text-sm mb-3 md:mb-4 tracking-wider" style={{ color: '#666666' }}>
            오늘의 환경
          </h2>
          <div className="space-y-3 md:space-y-4">
            {/* Weather */}
            <div>
              <p className="text-xs mb-2 tracking-wide" style={{ color: '#999999' }}>
                날씨
              </p>
              <div className="flex flex-wrap gap-1.5">
                {weatherOptions.map((w) => (
                  <button
                    key={w}
                    onClick={() => setWeather(w)}
                    className="px-3 py-1.5 rounded-lg text-sm transition-all"
                    style={{
                      backgroundColor: weather === w ? '#1A3C6E' : '#FAF9F6',
                      color: weather === w ? '#FAF9F6' : '#333333',
                      border: weather === w ? 'none' : '1px solid #e5e5e5',
                    }}
                  >
                    {w}
                  </button>
                ))}
              </div>
            </div>

            {/* Temperature */}
            <div>
              <p className="text-xs mb-2 tracking-wide" style={{ color: '#999999' }}>
                체감기온
              </p>
              <div className="flex flex-wrap gap-1.5">
                {temperatureOptions.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTemperature(t)}
                    className="px-3 py-1.5 rounded-lg text-sm transition-all"
                    style={{
                      backgroundColor: temperature === t ? '#1A3C6E' : '#FAF9F6',
                      color: temperature === t ? '#FAF9F6' : '#333333',
                      border: temperature === t ? 'none' : '1px solid #e5e5e5',
                    }}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Mood */}
            <div>
              <p className="text-xs mb-2 tracking-wide" style={{ color: '#999999' }}>
                기분
              </p>
              <div className="flex flex-wrap gap-1.5">
                {moodOptions.map((m) => (
                  <button
                    key={m}
                    onClick={() => setMood(m)}
                    className="px-3 py-1.5 rounded-lg text-sm transition-all"
                    style={{
                      backgroundColor: mood === m ? '#1A3C6E' : '#FAF9F6',
                      color: mood === m ? '#FAF9F6' : '#333333',
                      border: mood === m ? 'none' : '1px solid #e5e5e5',
                    }}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Format Selection */}
        <section className="bg-white rounded-lg p-5 md:p-6 shadow-sm">
          <div className="mb-4 md:mb-5">
            <h2 className="text-xs md:text-sm tracking-wider" style={{ color: '#666666' }}>
              형식 선택
            </h2>
            <p className="text-xs mt-1" style={{ color: '#999999' }}>
              최대 3개까지 선택 가능
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-3">
            {formatOptions.map((format) => {
              const isSelected = selectedFormats.includes(format);
              const isDisabled = !isSelected && selectedFormats.length >= 3;

              return (
                <button
                  key={format}
                  onClick={() => toggleFormat(format)}
                  disabled={isDisabled}
                  className="p-3 md:p-4 rounded-lg text-center transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  style={{
                    backgroundColor: isSelected ? '#1A3C6E' : '#FAF9F6',
                    border: isSelected ? 'none' : '1px solid #e5e5e5',
                    color: isSelected ? '#FAF9F6' : '#333333',
                  }}
                >
                  {format}
                </button>
              );
            })}
          </div>
        </section>

        {/* Content Input */}
        <section className="bg-white rounded-lg p-5 md:p-6 shadow-sm">
          <h2 className="text-xs md:text-sm mb-3 md:mb-4 tracking-wider" style={{ color: '#666666' }}>
            오늘의 기록
          </h2>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="오늘 하루는 어떠셨나요? 자유롭게 기록해주세요."
            className="w-full min-h-[200px] p-4 rounded-lg text-sm md:text-base leading-relaxed resize-none focus:outline-none focus:ring-1 focus:ring-blue-100 transition-all"
            style={{ 
              backgroundColor: '#FAF9F6',
              border: '1px solid #e5e5e5', 
              color: '#333' 
            }}
          />
        </section>

        {/* Save Button */}
        <div className="flex justify-center pb-4">
          <button
            onClick={handleSave}
            disabled={isSaving || selectedFormats.length === 0}
            className="px-8 py-3 rounded-lg flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 shadow-md"
            style={{ backgroundColor: '#1A3C6E', color: '#FAF9F6' }}
          >
            <Library className="w-5 h-5" />
            <span className="tracking-wide">{isSaving ? '저장 중...' : '서재로 이동'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
