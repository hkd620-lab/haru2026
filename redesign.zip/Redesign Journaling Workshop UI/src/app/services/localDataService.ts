// localStorage 기반 데이터 서비스 - Firebase 없이 완전 동작
// Firebase SDK의 네트워크 요청으로 인한 모바일 로딩 문제 해결

import { projectId, publicAnonKey } from '/utils/supabase/info';

const STORAGE_KEY = 'haru_records_v1';
let authToken: string | null = null;
let isSyncing = false;

export type RecordFormat = '일기' | '에세이' | '선교보고' | '일반보고' | '업무일지' | '여행기록';

export interface HaruRecord {
  id: string;
  uid: string;
  date: string;
  weather?: string;
  temperature?: string;
  mood?: string;
  formats?: RecordFormat[];
  polished?: boolean;
  polishedAt?: string | null;
  sayuContent?: string | null;
  sayuSavedAt?: string | null;
  mergeRating?: number;
  createdAt: string;
  updatedAt?: string;
  content?: string; // Added explicit content field
  [key: string]: any;
}

function generateId(): string {
  return `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function getAllRecords(): HaruRecord[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveAllRecords(records: HaruRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (e) {
    console.error('localStorage 저장 실패:', e);
  }
}

export const localDataService = {
  // 인증 토큰 설정 및 동기화 시작
  setAuth(token: string | null, uid: string | null) {
    authToken = token;
    if (token && uid) {
      this.sync(uid);
    }
  },

  // 서버와 데이터 동기화
  async sync(uid: string) {
    if (!authToken || isSyncing) return;
    isSyncing = true;

    try {
      // 1. 서버 데이터 가져오기
      // Authorization 헤더에 Anon Key를 사용하여 Gateway 통과 보장
      // 실제 유저 인증은 X-User-Token 헤더를 통해 수행
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d095746c/records`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'X-User-Token': authToken,
          }
        }
      );
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to fetch records: ${response.status} ${errorText}`);
      }
      const { records: serverRecords } = await response.json();
      
      // 2. 로컬 데이터와 병합
      const localRecords = this.getRecords(uid);
      const mergedMap = new Map<string, HaruRecord>();
      
      // 로컬 데이터 먼저 맵에 추가
      localRecords.forEach(r => mergedMap.set(r.id, r));
      
      // 서버 데이터 병합 (최신순 우선)
      let hasChanges = false;
      serverRecords.forEach((serverRecord: HaruRecord) => {
        const localRecord = mergedMap.get(serverRecord.id);
        if (!localRecord) {
          mergedMap.set(serverRecord.id, serverRecord);
          hasChanges = true;
        } else {
          // 타임스탬프 비교
          const serverTime = new Date(serverRecord.updatedAt || serverRecord.createdAt).getTime();
          const localTime = new Date(localRecord.updatedAt || localRecord.createdAt).getTime();
          
          if (serverTime > localTime) {
            mergedMap.set(serverRecord.id, serverRecord);
            hasChanges = true;
          }
        }
      });
      
      // 3. 변경사항이 있으면 로컬에 저장
      const mergedRecords = Array.from(mergedMap.values());
      if (hasChanges || mergedRecords.length !== localRecords.length) {
        const allData = getAllRecords();
        const otherUserData = allData.filter(r => r.uid !== uid);
        saveAllRecords([...otherUserData, ...mergedRecords]);
      }
      
      // 4. 병합된 최신 데이터를 서버에 업로드
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-d095746c/records`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'X-User-Token': authToken,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ records: mergedRecords }),
        }
      );
      
      // console.log('Sync completed successfully');
      
    } catch (e) {
      console.error('Sync failed:', e);
    } finally {
      isSyncing = false;
    }
  },

  // 사용자의 모든 기록 가져오기 (날짜 내림차순)
  getRecords(uid: string): HaruRecord[] {
    return getAllRecords()
      .filter((r) => r.uid === uid)
      .sort((a, b) => b.date.localeCompare(a.date));
  },

  // 날짜로 기록 가져오기
  getRecordByDate(uid: string, date: string): HaruRecord | null {
    return getAllRecords().find((r) => r.uid === uid && r.date === date) || null;
  },

  // 기록 추가 또는 업데이트 (upsert)
  upsertRecord(uid: string, date: string, data: Partial<HaruRecord>): HaruRecord {
    const allRecords = getAllRecords();
    const idx = allRecords.findIndex((r) => r.uid === uid && r.date === date);
    let result: HaruRecord;

    if (idx >= 0) {
      allRecords[idx] = {
        ...allRecords[idx],
        ...data,
        updatedAt: new Date().toISOString(),
      };
      result = allRecords[idx];
    } else {
      const newRecord: HaruRecord = {
        id: generateId(),
        uid,
        date,
        createdAt: new Date().toISOString(),
        ...data,
      };
      allRecords.push(newRecord);
      result = newRecord;
    }
    
    saveAllRecords(allRecords);
    
    // 변경 후 동기화 시도
    if (authToken) {
      this.sync(uid);
    }
    
    return result;
  },

  // ID로 기록 업데이트
  updateRecord(id: string, data: Partial<HaruRecord>): void {
    const allRecords = getAllRecords();
    const idx = allRecords.findIndex((r) => r.id === id);
    if (idx >= 0) {
      allRecords[idx] = {
        ...allRecords[idx],
        ...data,
        updatedAt: new Date().toISOString(),
      };
      saveAllRecords(allRecords);
      
      // 변경 후 동기화 시도
      if (authToken) {
        this.sync(allRecords[idx].uid);
      }
    }
  },

  // ID로 기록 삭제
  deleteRecord(id: string): void {
    const allRecords = getAllRecords();
    const record = allRecords.find(r => r.id === id);
    if (record) {
      const uid = record.uid;
      const filtered = allRecords.filter((r) => r.id !== id);
      saveAllRecords(filtered);
      
      // 변경 후 동기화 시도
      if (authToken) {
        // 서버에는 삭제된 상태를 반영해야 하는데, 
        // 현재 sync 로직은 "없는 것을 추가"하는 방식이라 
        // 로컬에서 삭제해도 서버에 있으면 다시 받아올 수 있음.
        // 완벽한 동기화를 위해서는 'deletedAt' 플래그나 soft delete를 사용해야 함.
        // 일단은 서버의 전체 리스트를 덮어쓰는 방식이 아니라서 한계가 있음.
        // 하지만 위의 sync 로직에서 POST는 "mergedRecords"를 보내므로,
        // 여기서 로컬 삭제 후 sync()를 부르면...
        // sync() 내부에서: 
        // 1. GET server (has record)
        // 2. Merge (local missing -> add back from server!)
        // 3. POST (has record)
        // => 삭제가 안 됨!
        
        // 해결책: 삭제 시에는 sync()를 부르지 말고, 
        // 직접 서버에 삭제 요청을 하거나, 전체 리스트를 덮어쓰는 API를 호출해야 함.
        // 이번 구현에서는 "POST /records"가 전체 리스트를 덮어쓰는(KV set) 방식이므로
        // 로컬 리스트(삭제된 상태)를 바로 보내버리면 됨.
        // 단, 다른 기기에서 추가된 데이터가 있을 수 있으므로 GET -> Merge -> Delete -> POST 순서가 맞음.
        
        // 간단한 해결책: deleteRecord 내에서 바로 POST 호출 (Optimistic)
        // 하지만 동기화 무결성을 위해선 복잡해짐.
        // 현재는 "삭제" 기능이 UI에 크게 노출되어 있지 않다면 일단 둠.
        // 만약 삭제가 중요하다면 sync 로직을 수정해야 함.
        
        // 수정된 sync 로직 제안: 
        // Delete 시에는 sync를 호출하되, 삭제된 ID를 기억해야 함?
        // 아니면 soft delete 사용.
        
        // 일단은 삭제 후 현재 상태를 강제로 푸시하는 함수를 별도로 만듦.
        this.forcePush(uid, filtered.filter(r => r.uid === uid));
      }
    }
  },
  
  // 강제 업로드 (삭제 시 사용)
  async forcePush(uid: string, records: HaruRecord[]) {
    if (!authToken) return;
    try {
        await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-d095746c/records`,
            {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${publicAnonKey}`,
                'X-User-Token': authToken,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ records }),
            }
          );
    } catch(e) { console.error(e); }
  },

  // 전체 데이터 내보내기 (JSON)
  exportData(uid: string): string {
    const records = this.getRecords(uid);
    return JSON.stringify(records, null, 2);
  },

  // 전체 데이터 삭제
  clearAllData(uid: string): void {
    const allRecords = getAllRecords().filter((r) => r.uid !== uid);
    saveAllRecords(allRecords);
    if(authToken) {
        this.forcePush(uid, []);
    }
  },

  // 통계 정보
  getStats(uid: string) {
    const records = this.getRecords(uid);
    const totalRecords = records.length;
    const polishedCount = records.filter((r) => r.polished).length;
    const sayuCount = records.filter((r) => r.sayuSavedAt).length;
    const formatCounts: Record<string, number> = {};
    records.forEach((r) => {
      r.formats?.forEach((f) => {
        formatCounts[f] = (formatCounts[f] || 0) + 1;
      });
    });
    return { totalRecords, polishedCount, sayuCount, formatCounts };
  },
};
