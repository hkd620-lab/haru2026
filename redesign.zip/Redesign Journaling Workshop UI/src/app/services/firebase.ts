// Firebase 완전 비활성화
// localDataService.ts를 사용합니다
export const auth = null;
export const db = null;
export const functions = null;
