import { GoogleGenerativeAI } from '@google/generative-ai';

// 기록 형식 타입 정의
export type RecordFormat = 'diary' | 'essay' | 'mission' | 'report' | 'work' | 'travel';

// 모델 설정 인터페이스
interface ModelConfig {
  model: string;
  maxOutputTokens: number;
  temperature: number;
  systemInstruction: string;
}

// 각 형식별 모델 및 프롬프트 설정 (요청서 기반)
const MODEL_CONFIGS: Record<RecordFormat, ModelConfig> = {
  diary: {
    model: 'gemini-2.0-flash',
    maxOutputTokens: 1000, // 약 800자 (토큰 여유 둠)
    temperature: 0.7,
    systemInstruction: `
      당신은 사용자의 일기를 다듬어주는 AI입니다.
      - 원문을 100% 읽고 반영하십시오.
      - 사용자의 표현, 문장 구조, 감정의 결을 최우선으로 존중하십시오.
      - 내용을 재창작하거나 새로운 사건을 추가하지 마십시오.
      - 감정을 과장하거나 교훈을 강요하지 마십시오.
      - 출력 길이는 최대 800자로 제한합니다.
    `
  },
  essay: {
    model: 'gemini-1.5-pro', // 2.5-pro가 아직 일반 공개 전일 수 있어 1.5-pro 사용 (추후 변경 가능)
    maxOutputTokens: 1200, // 900~1100자
    temperature: 0.8,
    systemInstruction: `
      당신은 사용자의 에세이를 문학적으로 다듬어주는 AI입니다.
      - 원문의 의미를 해치지 않는 선에서 문학적 구조를 보완하십시오.
      - 내용은 절대 변경하지 마십시오.
      - 1차적으로 글을 분석하고 최종적으로 세련된 문체로 완성하십시오.
      - 출력 길이는 900~1100자 사이로 맞추십시오.
    `
  },
  mission: {
    model: 'gemini-1.5-pro',
    maxOutputTokens: 1100, // 700~1000자
    temperature: 0.3,
    systemInstruction: `
      당신은 선교보고를 정리하는 AI입니다.
      - 사실(Fact) 중심으로 서술하십시오.
      - 기록된 내용 외에 임의로 내용을 추가하지 마십시오.
      - 감정적인 미사여구보다는 명확한 전달에 집중하십시오.
      - 출력 길이는 700~1000자 사이로 맞추십시오.
    `
  },
  report: {
    model: 'gemini-2.0-flash',
    maxOutputTokens: 900, // 600~800자
    temperature: 0.2,
    systemInstruction: `
      당신은 일반 보고서를 작성하는 AI입니다.
      - 핵심 내용을 요약하여 간결하게 작성하십시오.
      - 불필요한 감성 표현을 모두 제거하십시오.
      - 객관적이고 드라이한 어조를 유지하십시오.
      - 출력 길이는 600~800자 사이로 맞추십시오.
    `
  },
  work: {
    model: 'gemini-2.0-flash-lite',
    maxOutputTokens: 700, // 400~600자
    temperature: 0.1,
    systemInstruction: `
      당신은 업무일지를 정리하는 AI입니다.
      - 항목별(Bullet points)로 명확하게 정리하십시오.
      - 감정 표현을 금지합니다.
      - 업무 진행 상황, 결과, 계획 위주로 서술하십시오.
      - 출력 길이는 400~600자 사이로 맞추십시오.
    `
  },
  travel: {
    model: 'gemini-2.0-flash',
    maxOutputTokens: 1100, // 800~1000자
    temperature: 0.8,
    systemInstruction: `
      당신은 여행 기록을 생생하게 다듬어주는 AI입니다.
      - 현장 묘사를 중심으로 서술하십시오.
      - 원문에 있는 내용의 범위 내에서 표현을 확장하고 풍부하게 만드십시오.
      - 과도한 상상보다는 관찰한 사실을 감각적으로 표현하십시오.
      - 출력 길이는 800~1000자 사이로 맞추십시오.
    `
  }
};

export class GeminiService {
  private apiKey: string;
  private genAI: GoogleGenerativeAI;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
    this.genAI = new GoogleGenerativeAI(apiKey);
  }

  async polishContent(content: string, format: RecordFormat): Promise<string> {
    if (!content.trim()) return '';

    const config = MODEL_CONFIGS[format];
    
    // 모델 초기화
    const model = this.genAI.getGenerativeModel({
      model: config.model,
      systemInstruction: config.systemInstruction,
    });

    const generationConfig = {
      temperature: config.temperature,
      maxOutputTokens: config.maxOutputTokens,
    };

    try {
      const result = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: content }] }],
        generationConfig,
      });

      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini API Error:', error);
      // 에러 발생 시 사용자 친화적인 메시지보다는 에러 내용을 상위로 전달하여 UI에서 처리
      throw error;
    }
  }

  // 합본(Aggregation) 기능
  async aggregateContents(contents: string[], type: 'weekly' | 'monthly' | 'quarterly' | 'yearly'): Promise<string> {
    let modelName = 'gemini-2.0-flash';
    let maxTokens = 1500;
    let limitDesc = '1200~1500자';

    switch (type) {
      case 'weekly':
        modelName = 'gemini-2.0-flash';
        maxTokens = 1600; // ~1500자
        limitDesc = '1200~1500자';
        break;
      case 'monthly':
        modelName = 'gemini-2.0-flash';
        maxTokens = 2200; // ~2000자
        limitDesc = '1500~2000자';
        break;
      case 'quarterly':
        modelName = 'gemini-1.5-pro';
        maxTokens = 2800; // ~2500자
        limitDesc = '2000~2500자';
        break;
      case 'yearly':
        modelName = 'gemini-1.5-pro';
        maxTokens = 4000; // ~3500자
        limitDesc = '2500~3500자';
        break;
    }

    const systemInstruction = `
      당신은 사용자의 여러 기록을 하나로 통합하여 '합본'을 만드는 AI입니다.
      - 제공된 모든 기록을 100% 읽고 반영하십시오.
      - 빠진 날짜가 있더라도 임의로 내용을 생성해 채워넣지 마십시오.
      - 사건을 왜곡하거나 새로운 사건을 만들어내지 마십시오.
      - 반복되는 내용은 자연스럽게 통합하십시오.
      - 감성적인 과장이나 설교조를 피하십시오.
      - 전체 길이는 ${limitDesc} 사이로 작성하십시오.
    `;

    const model = this.genAI.getGenerativeModel({
      model: modelName,
      systemInstruction,
    });

    try {
      // 여러 개의 글을 하나의 프롬프트로 합쳐서 전달
      const combinedInput = contents.map((c, i) => `[기록 ${i+1}]\n${c}`).join('\n\n');
      
      const result = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: combinedInput }] }],
        generationConfig: {
          temperature: 0.5,
          maxOutputTokens: maxTokens,
        },
      });

      return result.response.text();
    } catch (error) {
      console.error('Gemini Aggregation Error:', error);
      throw error;
    }
  }
}
